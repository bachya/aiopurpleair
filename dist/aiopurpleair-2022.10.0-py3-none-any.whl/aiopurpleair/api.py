"""Define an API client."""
