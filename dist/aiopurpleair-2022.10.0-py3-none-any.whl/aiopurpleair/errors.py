"""Define package exceptions."""


class PurpleAirError(Exception):
    """Define a base exception."""

    pass
