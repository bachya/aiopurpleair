"""Define package constants."""
import logging

LOGGER = logging.getLogger(__package__)
