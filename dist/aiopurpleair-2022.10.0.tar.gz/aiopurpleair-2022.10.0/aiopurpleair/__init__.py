"""Define the aiopurpleair package."""
